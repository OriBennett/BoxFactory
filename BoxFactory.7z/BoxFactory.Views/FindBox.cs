﻿namespace BoxFactory.Services;

public class FindBox
{

}